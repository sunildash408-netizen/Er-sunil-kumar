ER SUNIL KUMAR WEBSITE — HINDI GUIDE

Files:
- index.html: website content
- style.css: design and responsive mobile layout
- script.js: English/Japanese switch, mobile menu, current year
- assets/sunil-profile.png: profile photo

IMPORTANT:
1. Keep the assets folder and the photo inside it. The website uses assets/sunil-profile.png.
2. To update your existing GitHub Pages site, upload/replace index.html, style.css, script.js, and upload the assets folder with sunil-profile.png inside it.
3. On GitHub, use Add file > Upload files. Drag these files and the assets folder contents into the repository root. Make sure the image ends up at assets/sunil-profile.png.
4. Click Commit changes and wait a few minutes. Refresh the website.
5. Your website URL remains:
   https://sunildash408-netizen.github.io/Er-sunil-kumar/

Your Facebook and TikTok links are included. Review all details before sharing publicly.
